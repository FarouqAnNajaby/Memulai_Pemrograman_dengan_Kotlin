// main function
fun main() {
    var value = 'A'
    do {
        value++
        print(value)
    } while (value <= 'Z')
}