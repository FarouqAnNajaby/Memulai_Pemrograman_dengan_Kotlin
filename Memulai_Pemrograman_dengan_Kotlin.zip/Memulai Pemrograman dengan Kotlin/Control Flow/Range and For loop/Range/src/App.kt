// main function
fun main() {
    val rangeInt = 1..10
    print(rangeInt.step)
}